
DROP INDEX idx_admins_email;
DROP INDEX idx_admins_user_id;
DROP TABLE admins;


CREATE TABLE products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  price REAL NOT NULL,
  image TEXT NOT NULL,
  category TEXT NOT NULL,
  variation TEXT NOT NULL,
  is_active BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_is_active ON products(is_active);

-- Migrar produtos existentes
INSERT INTO products (name, price, image, category, variation) VALUES
('Camiseta Branca', 80, 'https://i.imgur.com/W1UJ8vD.jpeg', 'roupas', 'completo'),
('Panela', 50, 'https://i.imgur.com/7QZ9w0K.jpeg', 'cozinha', 'cor'),
('Jaqueta Jeans', 150, 'https://i.imgur.com/0pEka0U.jpeg', 'roupas', 'tamanho');


DROP INDEX idx_products_is_active;
DROP INDEX idx_products_category;
DROP TABLE products;


DROP TABLE admin_credentials;

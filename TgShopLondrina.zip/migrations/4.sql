
DELETE FROM admin_credentials WHERE username = 'biel';

INSERT INTO admin_credentials (username, password_hash, created_at, updated_at)
VALUES (
  'biel',
  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
);

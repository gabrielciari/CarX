
DELETE FROM admin_credentials WHERE username = 'biel';

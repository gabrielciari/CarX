
DROP INDEX idx_orders_payment_status;
DROP INDEX idx_orders_user_id;
DROP TABLE orders;

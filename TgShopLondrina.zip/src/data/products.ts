export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: 'roupas' | 'acessorios' | 'cozinha';
  variation: 'cor' | 'tamanho' | 'completo' | 'none';
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Camiseta Branca',
    price: 80,
    image: 'https://i.imgur.com/W1UJ8vD.jpeg',
    category: 'roupas',
    variation: 'completo'
  },
  {
    id: '2',
    name: 'Panela',
    price: 50,
    image: 'https://i.imgur.com/7QZ9w0K.jpeg',
    category: 'cozinha',
    variation: 'cor'
  },
  {
    id: '3',
    name: 'Jaqueta Jeans',
    price: 150,
    image: 'https://i.imgur.com/0pEka0U.jpeg',
    category: 'roupas',
    variation: 'tamanho'
  }
];

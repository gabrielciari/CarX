import { useState } from 'react';
import { useCart } from '@/react-app/hooks/useCart';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (message: string) => void;
}

export function CartModal({ isOpen, onClose, onShowToast }: CartModalProps) {
  const { cart, removeFromCart, total } = useCart();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [number, setNumber] = useState('');
  const [complement, setComplement] = useState('');

  if (!isOpen) return null;

  const handleSendWhatsApp = () => {
    if (cart.length === 0) {
      alert('Seu carrinho está vazio!');
      return;
    }

    if (!name || !phone || !address || !number) {
      alert('⚠️ Ops! Você precisa preencher: Nome, Telefone, Endereço e Número.');
      return;
    }

    let message = 'Olá, gostaria de fazer o pedido:\n\n';
    cart.forEach((item, i) => {
      message += `${i + 1}. ${item.name} (${item.variations}) - R$ ${item.price.toFixed(2)}\n`;
    });

    message += `\n🧾 Total: R$ ${total.toFixed(2)}\n`;
    message += `\n📍 *Dados do Cliente:*`;
    message += `\n👤 Nome: ${name}`;
    message += `\n📞 Telefone: ${phone}`;
    message += `\n🏠 Endereço: ${address}, Nº ${number}`;
    if (complement) {
      message += `\n🏢 Complemento: ${complement}`;
    }

    const whatsappNumber = '554399632114';
    const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleRemove = (index: number) => {
    removeFromCart(index);
    onShowToast('Item removido do carrinho.');
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[999]">
      <div className="bg-[#1a1a1a] p-5 rounded-lg w-[400px] max-h-[80vh] overflow-y-auto text-white flex flex-col">
        <h2 className="mt-0 text-red-600 font-bold mb-4">🛒 Seu Carrinho</h2>

        <div className="mb-5">
          {cart.length === 0 ? (
            <p>Seu carrinho está vazio.</p>
          ) : (
            <>
              {cart.map((item, index) => (
                <div
                  key={index}
                  className="border-b border-[#444] py-2.5 text-base flex justify-between items-center"
                >
                  <span>
                    {item.name} ({item.variations}) - R$ {item.price.toFixed(2)}
                  </span>
                  <button
                    onClick={() => handleRemove(index)}
                    className="bg-transparent border-none text-red-600 text-xl cursor-pointer px-2 font-bold hover:text-red-500"
                    title="Remover item"
                  >
                    ×
                  </button>
                </div>
              ))}
              <div className="mt-4 pt-4 border-t border-[#444]">
                <div className="flex justify-between text-xl font-bold">
                  <span>Total:</span>
                  <span className="text-green-400">R$ {total.toFixed(2)}</span>
                </div>
              </div>
            </>
          )}
        </div>

        <div className="space-y-2.5">
          <div>
            <label className="block mb-1">Nome e Sobrenome:</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: João da Silva"
              className="w-full p-2 rounded border-none bg-white text-black"
            />
          </div>

          <div>
            <label className="block mb-1">Número para contato:</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Ex: (43) 99999-0000"
              className="w-full p-2 rounded border-none bg-white text-black"
            />
          </div>

          <div>
            <label className="block mb-1">Endereço (Rua, Avenida...):</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Ex: Rua das Flores"
              className="w-full p-2 rounded border-none bg-white text-black"
            />
          </div>

          <div>
            <label className="block mb-1">Número da casa ou prédio:</label>
            <input
              type="text"
              value={number}
              onChange={(e) => setNumber(e.target.value)}
              placeholder="Ex: 123"
              className="w-full p-2 rounded border-none bg-white text-black"
            />
          </div>

          <div>
            <label className="block mb-1">Apto e bloco (opcional):</label>
            <input
              type="text"
              value={complement}
              onChange={(e) => setComplement(e.target.value)}
              placeholder="Ex: Apto 202, Bloco B"
              className="w-full p-2 rounded border-none bg-white text-black"
            />
          </div>
        </div>

        <button
          onClick={handleSendWhatsApp}
          className="w-full bg-green-600 hover:bg-green-700 text-white border-none p-2.5 rounded mt-2.5 font-bold cursor-pointer transition-colors"
        >
          📲 Enviar Pedido
        </button>

        <button
          onClick={onClose}
          className="w-full bg-[#444] hover:bg-[#555] text-white border-none p-2.5 rounded mt-2.5 cursor-pointer transition-colors"
        >
          ❌ Fechar
        </button>
      </div>
    </div>
  );
}

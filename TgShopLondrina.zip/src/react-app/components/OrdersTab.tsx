import { useState, useEffect } from 'react';
import { Package, CheckCircle, XCircle, Clock } from 'lucide-react';

interface Order {
  id: number;
  user_email: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  customer_number: string;
  customer_complement: string;
  total_amount: number;
  payment_status: string;
  items: Array<{
    name: string;
    price: number;
    variations: string;
  }>;
  created_at: string;
}

export function OrdersTab() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const response = await fetch('/api/orders');
      const data = await response.json();
      setOrders(data.orders || []);
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (orderId: number, newStatus: string) => {
    try {
      await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      loadOrders();
    } catch (error) {
      console.error('Error updating order status:', error);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      default:
        return <Package className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'text-green-500';
      case 'rejected':
        return 'text-red-500';
      case 'pending':
        return 'text-yellow-500';
      default:
        return 'text-gray-500';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'approved':
        return 'Aprovado';
      case 'rejected':
        return 'Recusado';
      case 'pending':
        return 'Pendente';
      default:
        return status;
    }
  };

  if (loading) {
    return <div className="text-center py-8">Carregando pedidos...</div>;
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <Package className="w-6 h-6" />
        Pedidos ({orders.length})
      </h2>

      {orders.length === 0 ? (
        <div className="bg-gray-800 p-8 rounded-lg text-center">
          <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">Nenhum pedido ainda</p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div key={order.id} className="bg-gray-800 p-6 rounded-lg">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    {getStatusIcon(order.payment_status)}
                    <span className={`font-bold ${getStatusColor(order.payment_status)}`}>
                      {getStatusLabel(order.payment_status)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400">
                    Pedido #{order.id} • {new Date(order.created_at).toLocaleString('pt-BR')}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-green-400">
                    R$ {order.total_amount.toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                <div>
                  <p className="text-gray-400">Cliente</p>
                  <p className="font-semibold">{order.customer_name}</p>
                </div>
                <div>
                  <p className="text-gray-400">Telefone</p>
                  <p className="font-semibold">{order.customer_phone}</p>
                </div>
                <div>
                  <p className="text-gray-400">E-mail</p>
                  <p className="font-semibold">{order.user_email}</p>
                </div>
                <div>
                  <p className="text-gray-400">Endereço</p>
                  <p className="font-semibold">
                    {order.customer_address}, {order.customer_number}
                    {order.customer_complement && ` - ${order.customer_complement}`}
                  </p>
                </div>
              </div>

              <div className="border-t border-gray-700 pt-4 mb-4">
                <p className="text-gray-400 mb-2">Itens do pedido:</p>
                <div className="space-y-1">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>
                        {item.name} ({item.variations})
                      </span>
                      <span className="text-green-400">R$ {item.price.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {order.payment_status === 'pending' && (
                <div className="flex gap-2">
                  <button
                    onClick={() => handleUpdateStatus(order.id, 'approved')}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded font-bold transition-colors"
                  >
                    Aprovar Manualmente
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(order.id, 'rejected')}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded font-bold transition-colors"
                  >
                    Recusar
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

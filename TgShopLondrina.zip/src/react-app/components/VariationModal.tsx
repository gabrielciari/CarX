import { useState } from 'react';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  variation: string;
  is_active: number;
}

interface VariationModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (variations: string) => void;
}

export function VariationModal({ product, isOpen, onClose, onConfirm }: VariationModalProps) {
  const [color, setColor] = useState('Vermelho');
  const [size, setSize] = useState('M');

  if (!isOpen || !product) return null;

  const handleConfirm = () => {
    const variations: string[] = [];
    
    if (product.variation === 'cor' || product.variation === 'completo') {
      variations.push(`Cor: ${color}`);
    }
    
    if (product.variation === 'tamanho' || product.variation === 'completo') {
      variations.push(`Tamanho: ${size}`);
    }

    onConfirm(variations.join(', '));
  };

  const showColor = product.variation === 'cor' || product.variation === 'completo';
  const showSize = product.variation === 'tamanho' || product.variation === 'completo';

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[9999]">
      <div className="bg-[#1a1a1a] p-5 rounded-lg w-[300px] text-white">
        <h3 className="mt-0 text-red-600 font-bold mb-4">Escolha as opções</h3>
        
        {showColor && (
          <div className="mb-2.5">
            <select
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="w-full p-2 mb-2.5 rounded bg-[#222] border-none text-white"
            >
              <option value="Vermelho">Vermelho</option>
              <option value="Preto">Preto</option>
              <option value="Branco">Branco</option>
            </select>
          </div>
        )}

        {showSize && (
          <div className="mb-2.5">
            <select
              value={size}
              onChange={(e) => setSize(e.target.value)}
              className="w-full p-2 mb-2.5 rounded bg-[#222] border-none text-white"
            >
              <option value="P">P</option>
              <option value="M">M</option>
              <option value="G">G</option>
              <option value="GG">GG</option>
            </select>
          </div>
        )}

        <button
          onClick={handleConfirm}
          className="w-full p-2.5 mt-2.5 rounded font-bold bg-red-600 hover:bg-red-700 text-white border-none cursor-pointer transition-colors"
        >
          Adicionar
        </button>
        
        <button
          onClick={onClose}
          className="w-full p-2.5 mt-2 rounded font-bold bg-[#444] hover:bg-[#555] text-white border-none cursor-pointer transition-colors"
        >
          Cancelar
        </button>
      </div>
    </div>
  );
}
